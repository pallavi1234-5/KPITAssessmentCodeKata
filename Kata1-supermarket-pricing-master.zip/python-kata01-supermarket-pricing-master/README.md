More Detail here: http://codekata.com/kata/kata01-supermarket-pricing/
